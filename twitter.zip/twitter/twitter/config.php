<?php

define('CONSUMER_KEY', 'xvVdeole07egfP8CI6Dei7Uss');
define('CONSUMER_SECRET', 'sHvInVHDYmkZUNXlmpv5zGR5mP17gifLC1sjfmine1Rujc9748');
define('OAUTH_CALLBACK', 'http://www.mediafire.com/file/p9htvgtc3aehvz2/callback.php');

?>